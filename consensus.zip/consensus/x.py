import socket
import threading
from queue import Queue
import time
import sys
import pickle
from threading import Condition, Thread
import random
import conf

#Main

F = [0]*1000
T = [0]*1000
cv = Condition()
    

def list_creator(x):
    lst = []
    for i in range(x):
        lst.append((5013+i))
    return lst
    
nodes = conf.nodes

queue_set = {} #Dictionary which stores the queues for each port so that messages can be sent to all ports.
global_queue = Queue() #Queue thats stores all messages recieved from other processes.

def connector(p,q):
    """Connects to a port p and send a message from its queue to the port itself
    
    p:the port to connect to
    q:the queue of that port in the queue_set
    Precondition: p is in ports list and q is queue_set[port]
    """
    while True:
        try:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.connect(('127.0.0.1', p))
            break
        except:
            time.sleep(1)
    while True:
            msg = q.get()
            if msg == "decided":
                # print("received msg")
                client.close()
                break
            data_string = pickle.dumps(msg)
            rand_sleep = random.randrange(0,50)
            time.sleep(float(rand_sleep)/float(100))
            client.send(data_string)

    
def receiver(conn):
    """Recieves messages from a connection (i.e a process) and puts them on the
    global queue.
    
    conn: the connection from a running port process
    Precondition: conn is a connection from a port that is in ports list.
    """
    while True:
        try:
            dat = conn.recv(4096)
            if dat == b'':
                # print("connection closed")
                break
        except:
            # print("incoming connection broke")
            break
        try:
            data= pickle.loads(dat)
            if data[0] == False:
                while True:
                    with cv:
                        F[(data[1])] += 1
                        cv.notifyAll()
                        break
            else:
                while True:
                    with cv:
                        T[(data[1])] += 1
                        cv.notifyAll()
                        break
        except:
            pass

# 
# def acceptor():
#     """Accepts incoming connections from other ports and starts the reciever thread. """
#     while True:
#         conn, addr = serv.accept()
#         y = threading.Thread(target=receiver, args=(conn,))
#         y.start()
        

serv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serv.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
server_index = int(sys.argv[1])
data = nodes[server_index]
port = data[1]
serv.bind(('127.0.0.1',port))
serv.listen(3)
for node in nodes:
    queue_set[node[1]]= Queue()
    z = threading.Thread(target=connector, args=(node[1],queue_set[node[1]]))
    z.start()
    conn, addr = serv.accept()
    y = threading.Thread(target=receiver, args=(conn,))
    y.start()


# u = threading.Thread(target=acceptor, args=[])
# u.start()

#Algorithm
def prRed(skk):
    """Pretty prints the input string skk in red on command line.
    
    skk: a string
    Source: https://www.geeksforgeeks.org/print-colors-python-terminal/
    """
    print("\033[91m {}\033[00m" .format(skk))
    
def prGreen(skk):
    """Pretty prints the input string skk in green on command line.
    
    skk: a string
    Source: https://www.geeksforgeeks.org/print-colors-python-terminal/
    """
    print("\033[92m {}\033[00m" .format(skk)) 

TCTR = 0 #True counter
FCTR = 0 # False Counter
e = True if sys.argv[2] == "True" else False #input vote
r = 0 #round number
decided = False #whether this process has decided or not
acc = 0 #when acc=3 it resets the round number to the one of other processes to ensure if a process only started running late it is at the same round as other processes
majority=round((2/3)*int(sys.argv[3])) #2/3 of all processes participating

while True:
    for q in queue_set.values(): #Broadcast (e,r)
            # print("for " + sys.argv[1] + ": " + e + "," + str(r))
        tup = (e,r)
        q.put(tup)
    if decided:
        for q in queue_set.values(): #Broadcast (e,r)
            # print("for " + sys.argv[1] + ": " + e + "," + str(r))
            q.put("decided")
        break
    else:
        while True:
            with cv:

                    while F[r] + T[r] < majority:
                        cv.wait()
                    # print("here")
                    print("False votes at round " + str(r) + " for port number " + str(port) + " is " + str(F[r]))
                    print("True votes at round " + str(r) + " for port number " + str(port) + " is " + str(T[r]))
                    if T[r] >= majority:
                        e = True
                        decided = True
                    elif F[r] >= majority:
                        e = False
                        decided = True
                    else:
                        e = (T[r] > F[r])
                    r += 1
                    print("At port number " + str(port) + " the current vote is " + str(e) + " in round number " + str(r) + " and the status of whether it has decided is " + str(decided))
                    break
print(" Number of rounds till decision was reached for port number " + str(port)+ " is " + str(r))
f=open(str(port)+'.pickle', 'ab')
# s=open('a.pickle', 'ab')
pickle.dump(r,f)
# pickle.dump(r,s)
f.close()

# s.close()
# 
# g=open('a.pickle', 'rb')
# 
# while True: 
#     objs = []
#     while 1:
#         try:
#             objs.append(pickle.load(g))
#         except EOFError:
#             break
#     print(objs)
#     if (len(objs) < 4):
#         pass
#     else:
#         open('a.pickle','w').close()
#         break

# f=open('a.pickle', 'ab')
# pickle.dump(r,f)
# f.close()
