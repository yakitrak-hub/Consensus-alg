import os
import pickle
import csv 

os.system('gtimeout 15 python a.py 5013 True & gtimeout 15 python a.py 5014 False & gtimeout 15 python a.py 5015 True & gtimeout 15 python a.py 5016 False')
# os.system('python a.py 5003 True & python a.py 5004 False & python a.py 5005 True & python a.py 5006 False & wait')
#os.system('python b.py 5000 True & python b.py 5001 True & python b.py 5002 True & python b.py 5003 False & python b.py 5004 True & python b.py 5005 True & python b.py 5006 True & python b.py 5007 False & python b.py 5008 True & python b.py 5009 False & wait')
          
os.system('gtimeout 30 python b.py 5000 True & gtimeout 30 python b.py 5001 True & gtimeout 30 python b.py 5002 True & gtimeout 30 python b.py 5003 False & gtimeout 30 python b.py 5004 True & gtimeout 30 python b.py 5005 True & gtimeout 30 python b.py 5006 True & gtimeout 30 python b.py 5007 False & gtimeout 30 python b.py 5008 True & gtimeout 30 python b.py 5009 False')

 
# g=open('a.pickle', 'rb')
# objs = []
# while 1:
#     try:
#         objs.append(pickle.load(g))
#     except EOFError:
#         break
#     
# 
#     
# x4 = max(objs)
# print(x4)

# print("hey")
g=open('5003.pickle', 'rb')
# print("here")
objs = []
while 1:
    try:
        objs.append(pickle.load(g))
    except EOFError:
        break
    
g=open('5004.pickle', 'rb')
# print("here")
while 1:
    try:
        objs.append(pickle.load(g))
    except EOFError:
        break

g=open('5005.pickle', 'rb')
# print("here")
while 1:
    try:
        objs.append(pickle.load(g))
    except EOFError:
        break
    
g=open('5006.pickle', 'rb')
# print("here")
while 1:
    try:
        objs.append(pickle.load(g))
    except EOFError:
        break
    
x4 = max(objs)
print(x4)

open('5003.pickle','w').close()
open('5004.pickle','w').close()
open('5005.pickle','w').close()
open('5006.pickle','w').close()


# open('a.pickle','w').close()

# s=open('b.pickle', 'rb')
# 
# lst = []
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break

s=open('5000.pickle', 'rb')

lst = []
while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break

s=open('5001.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break

s=open('5002.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break

s=open('5003.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break

s=open('5004.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break
    
s=open('5005.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break
    
s=open('5006.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break
    
s=open('5007.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break
    
s=open('5008.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break
    
s=open('5009.pickle', 'rb')

while 1:
    try:
        lst.append(pickle.load(s))
    except EOFError:
        break
    
x10 = max(lst)
print(x10)

open('5000.pickle','w').close()
open('5001.pickle','w').close()
open('5002.pickle','w').close()
open('5003.pickle','w').close()
open('5004.pickle','w').close()
open('5005.pickle','w').close()
open('5006.pickle','w').close()
open('5007.pickle','w').close()
open('5008.pickle','w').close()
open('5009.pickle','w').close()


# open('b.pickle','w').close()

with open("data.csv","a",newline='\n') as csv_file:
    csv_app = csv.writer(csv_file)
    csv_app.writerow([x4,x10])