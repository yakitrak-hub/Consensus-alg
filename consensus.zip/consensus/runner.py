import os
import pickle
import csv
import sys

def string_gen(n,t):
    tr = t
    st = ""
    for i in range(n):    
        if tr > 0:
            if t==n:
                if tr > 1:
                    st = st + 'python x.py ' + str(5013+i) + " True " + sys.argv[1] + " & "
                else:
                    st = st + 'python x.py ' + str(5013+i) + " True " + sys.argv[1]
            else:
                st = st + 'python x.py ' + str(5013+i) + " True " + sys.argv[1] + " & "
            tr = tr-1   
        else:
            if i < n - 1: 
                st = st + 'python x.py ' + str(5013+i) + " False " + sys.argv[1] + " & "
            else:
                st = st + 'python x.py ' + str(5013+i) + " False " + sys.argv[1]
    return st
                    

print(string_gen(int(sys.argv[1]),int(sys.argv[2])))
os.system(string_gen(int(sys.argv[1]),int(sys.argv[2])))

print("here")

def objs_app(n):
    objs = []
    for i in range(n):
        g = open(str(5003+i) + '.pickle', 'rb')
        while 1:
            try:
                objs.append(pickle.load(g))
            except EOFError:
                break
        open(str(5003+i) + '.pickle','w').close()
    m = max(objs)
    print(m)
    with open("data.csv","a",newline='\n') as csv_file:
        csv_app = csv.writer(csv_file)
        csv_app.writerow([m])

objs_app(int(sys.argv[1]))

#NOW ONLY PLOTTING CDF FROM CSV LEFT.

# g=open('5003.pickle', 'rb')
# # print("here")
# objs = []
# while 1:
#     try:
#         objs.append(pickle.load(g))
#     except EOFError:
#         break
#     
# g=open('5004.pickle', 'rb')
# # print("here")
# while 1:
#     try:
#         objs.append(pickle.load(g))
#     except EOFError:
#         break
# 
# g=open('5005.pickle', 'rb')
# # print("here")
# while 1:
#     try:
#         objs.append(pickle.load(g))
#     except EOFError:
#         break
#     
# g=open('5006.pickle', 'rb')
# # print("here")
# while 1:
#     try:
#         objs.append(pickle.load(g))
#     except EOFError:
#         break
#     
# x4 = max(objs)
# print(x4)
# 
# open('5003.pickle','w').close()
# open('5004.pickle','w').close()
# open('5005.pickle','w').close()
# open('5006.pickle','w').close()
# 
# 
# # open('a.pickle','w').close()
# 
# # s=open('b.pickle', 'rb')
# # 
# # lst = []
# # while 1:
# #     try:
# #         lst.append(pickle.load(s))
# #     except EOFError:
# #         break
# 
# s=open('5000.pickle', 'rb')
# 
# lst = []
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
# 
# s=open('5001.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
# 
# s=open('5002.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
# 
# s=open('5003.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
# 
# s=open('5004.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
#     
# s=open('5005.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
#     
# s=open('5006.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
#     
# s=open('5007.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
#     
# s=open('5008.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
#     
# s=open('5009.pickle', 'rb')
# 
# while 1:
#     try:
#         lst.append(pickle.load(s))
#     except EOFError:
#         break
#     
# x10 = max(lst)
# print(x10)
# 
# open('5000.pickle','w').close()
# open('5001.pickle','w').close()
# open('5002.pickle','w').close()
# open('5003.pickle','w').close()
# open('5004.pickle','w').close()
# open('5005.pickle','w').close()
# open('5006.pickle','w').close()
# open('5007.pickle','w').close()
# open('5008.pickle','w').close()
# open('5009.pickle','w').close()
# 
# 
# # open('b.pickle','w').close()
# 
# with open("data.csv","a",newline='\n') as csv_file:
#     csv_app = csv.writer(csv_file)
#     csv_app.writerow([x4,x10])